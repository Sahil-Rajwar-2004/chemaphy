#INFO

author = "Sahil Rajwar"
version = "2.12.2"
authorEmail = "justsahilrajwar2004@gmail.com"
HomePage = "https://github.com/Sahil-Rajwar-2004/chemaphy"
