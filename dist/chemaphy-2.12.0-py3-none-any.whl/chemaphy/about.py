#INFO

author = "Sahil Rajwar"
version = "2.12.0"
authorEmail = "justsahilrajwar2004@gmail.com"
homepage = "https://github.com/Sahil-Rajwar-2004/chemaphy"
