#Info

author = "Sahil Rajwar"
version = "2.10.0"
authorEmail = "justsahilrajwar2004@gmail.com"
homepage = "https://github.com/Sahil-Rajwar-2004/chemaphy"
